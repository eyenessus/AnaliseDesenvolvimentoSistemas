package cineflix.cenaflixpodcast.screens;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;
import cineflix.cenaflixpodcast.model.Podcast;
import cineflix.cenaflixpodcast.model.Usuario;
import jakarta.persistence.EntityManager;

import java.awt.*;

public class ListagemScreen extends JFrame {
    private String grant;

    public ListagemScreen(Usuario user, EntityManager manager) {
        grant = user.getGrant();
        setTitle("CENAFLIX - Listagem de Podcasts");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 5, 5);
        c.fill = GridBagConstraints.HORIZONTAL;

        JLabel title = new JLabel("CENAFLIX", JLabel.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 2;
        panel.add(title, c);

        JLabel subtitle = new JLabel("LISTAGEM", JLabel.CENTER);
        subtitle.setFont(new Font("Arial", Font.BOLD, 14));
        c.gridy = 1;
        panel.add(subtitle, c);

        JLabel searchLabel = new JLabel("Pesquisar podcast por produtor:");
        c.gridy = 2;
        c.gridwidth = 1;
        panel.add(searchLabel, c);

        JTextField searchField = new JTextField(20);
        c.gridx = 1;
        panel.add(searchField, c);

        String[] columnNames = { "ID", "Produtor", "Nome do Episódio", "N° Episódio", "Duração", "URL do Repo" };
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        c.gridx = 0;
        c.gridy = 3;
        c.gridwidth = 2;
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 1.0;
        c.weighty = 1.0;
        panel.add(scrollPane, c);

        JButton excluirButton = new JButton("Excluir");
        c.gridy = 4;
        c.fill = GridBagConstraints.NONE;
        c.anchor = GridBagConstraints.LAST_LINE_END;
        c.weightx = 0;
        c.weighty = 0;
        excluirButton.setEnabled(grant.equals("ADMIN"));
        panel.add(excluirButton, c);

        JButton cadastrarButton = new JButton("Cadastrar");
        c.gridy = 4;
        c.fill = GridBagConstraints.NONE;
        c.anchor = GridBagConstraints.FIRST_LINE_START;
        c.weightx = 0;
        c.weighty = 0;
        cadastrarButton.setEnabled(grant.equals("ADMIN") || grant.equals("OPER"));
        panel.add(cadastrarButton, c);

        add(panel);

        searchField.addActionListener(e -> {
            String search = searchField.getText();
            List<Podcast> podcast = manager
                    .createQuery("SELECT p FROM Podcast p WHERE p.usuario_id = :user AND p.produtor LIKE :search",
                            Podcast.class)
                    .setParameter("user", user).setParameter("search", "%" + search + "%").getResultList();
            model.setRowCount(0);
            for (Podcast p : podcast) {
                model.addRow(new Object[] { p.getId(), p.getProdutor(), p.getNomeEpisodio(), p.getNumeroEpisodio(),
                        p.getDuracaoEpisodio(), p.getUrlRepositorio() });
            }
        });

        List<Podcast> podcast = manager.createQuery("SELECT p FROM Podcast p WHERE p.usuario_id = :user", Podcast.class)
                .setParameter("user", user).getResultList();

        for (Podcast p : podcast) {
            model.addRow(new Object[] { p.getId(), p.getProdutor(), p.getNomeEpisodio(), p.getNumeroEpisodio(),
                    p.getDuracaoEpisodio(), p.getUrlRepositorio() });
        }

        setVisible(true);

        excluirButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                Podcast podcastModel = manager.find(Podcast.class, (int) model.getValueAt(selectedRow, 0));
                manager.getTransaction().begin();
                manager.remove(podcastModel);
                manager.getTransaction().commit();
                model.removeRow(selectedRow);
                JOptionPane.showMessageDialog(this, "Podcast excluído com sucesso!");
            } else {
                JOptionPane.showMessageDialog(this, "Selecione um podcast para excluir!");
            }
        });

        cadastrarButton.addActionListener(e -> {
            new CadastroScreen(user, manager);
            dispose();
        });
    }

}
