package cineflix.cenaflixpodcast.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Podcast {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @ManyToOne
    @JoinColumn(name = "usuario_id",nullable = false)
    private Usuario usuario_id;
    private String produtor;
    private String nome_episodio;
    private int numero_episodio;
    private int duracao_episodio;
    private String url_repositorio;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Usuario getUsuarioId() {
        return usuario_id;
    }

    public void setUsuario(Usuario usuarioId) {
        this.usuario_id = usuarioId;
    }

    public String getProdutor() {
        return produtor;
    }

    public void setProdutor(String produtor) {
        this.produtor = produtor;
    }

    public String getNomeEpisodio() {
        return nome_episodio;
    }

    public void setNomeEpisodio(String nomeEpisodio) {
        this.nome_episodio = nomeEpisodio;
    }

    public int getNumeroEpisodio() {
        return numero_episodio;
    }

    public void setNumeroEpisodio(int numeroEpisodio) {
        this.numero_episodio = numeroEpisodio;
    }

    public int getDuracaoEpisodio() {
        return duracao_episodio;
    }

    public void setDuracaoEpisodio(int duracaoEpisodio) {
        this.duracao_episodio = duracaoEpisodio;
    }

    public String getUrlRepositorio() {
        return url_repositorio;
    }

    public void setUrlRepositorio(String urlRepositorio) {
        this.url_repositorio = urlRepositorio;
    }
}
