package cineflix.cenaflixpodcast.screens;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import cineflix.cenaflixpodcast.model.Usuario;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

public class LoginScreen extends JFrame {
    private String grant = "ADMIN";

    public LoginScreen() {
        setTitle("CenaFlix Podcast - Login");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLayout(new BorderLayout());
        showScreen();
    }

    public void showScreen() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 10, 10, 10);

        // Título
        JLabel title = new JLabel("CenaFlix", JLabel.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 32));
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 2;
        c.weightx = 1;
        panel.add(title, c);

        // Campo de Email
        JLabel emailTitle = new JLabel("Email");
        JTextField emailField = new JTextField(20);
        emailField.setFont(new Font("Arial", Font.PLAIN, 14));
        c.gridx = 0;
        c.gridy = 1;
        c.gridwidth = 1;
        c.weightx = 0.5;
        panel.add(emailTitle, c);

        c.gridx = 1;
        c.gridy = 1;
        c.gridwidth = 1;
        panel.add(emailField, c);

        // Campo de Senha
        JLabel passwordTitle = new JLabel("Senha");
        JPasswordField passwordField = new JPasswordField(20);
        passwordField.setFont(new Font("Arial", Font.PLAIN, 14));
        c.gridx = 0;
        c.gridy = 2;
        c.gridwidth = 1;
        panel.add(passwordTitle, c);

        c.gridx = 1;
        c.gridy = 2;
        panel.add(passwordField, c);

        // Botão de Login
        JButton loginButton = new JButton("Login");
        loginButton.setFont(new Font("Arial", Font.BOLD, 16));
        loginButton.setBackground(new Color(0, 123, 255));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFocusPainted(false);
        loginButton.setPreferredSize(new Dimension(100, 40));
        c.gridx = 1;
        c.gridy = 3;
        c.gridwidth = 1;
        c.insets = new Insets(20, 10, 10, 10);
        panel.add(loginButton, c);

        // Adiciona o painel à tela
        panel.setBackground(new Color(240, 240, 240));
        add(panel, BorderLayout.CENTER);

        setVisible(true);

        loginButton.addActionListener(e -> {
            String email = emailField.getText();
            String senha = new String(passwordField.getPassword());

            EntityManagerFactory fabricaEntidade = Persistence.createEntityManagerFactory("podcast");
            EntityManager manager = fabricaEntidade.createEntityManager();
            try {
                Usuario usuario = manager.createQuery("SELECT u FROM Usuario u WHERE u.email = :email", Usuario.class)
                        .setParameter("email", email).getSingleResult();

                if (emailField.getText().equals("")) {
                    System.out.println("Email não pode ser vazio");
                } else if (new String(passwordField.getPassword()).equals("")) {
                    System.out.println("Senha não pode ser vazia");
                } else if (usuario != null && usuario.getSenha().equals(senha) && usuario.getEmail().equals(email)) {
                    String grantSys = usuario.getGrant();
                    grant = grantSys;
                    String grantTypeResume = grantSys.equals( "USER") ? "USUÁRIO": grantSys.equals( "OPER") ? "OPERADOR" : "ADMINISTRADOR";
                    JOptionPane.showMessageDialog(null, "Olá " + usuario.getNome() + ", sua permissão é de "
                            + grantTypeResume + ". Seja bem-vindo!");
                    new ListagemScreen(usuario,manager);
                    dispose();
                } else {
                    System.out.println("Email ou senha incorretos");
                }
            } catch (IllegalStateException ex) {
                System.out.println("Usuário não encontrado: " + ex.getMessage());
                manager.close();
                fabricaEntidade.close();
            }

        });
    }
}
