/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package cineflix.cenaflixpodcast;

import cineflix.cenaflixpodcast.screens.LoginScreen;

/**
 *
 * @author emers
 */
public class CenaflixPodCast {

    public static void main(String[] args) {
        new LoginScreen();
        System.out.println("Working!");
    }
}
