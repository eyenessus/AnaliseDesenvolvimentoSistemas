package cineflix.cenaflixpodcast.screens;

import javax.swing.*;

import cineflix.cenaflixpodcast.model.Podcast;
import cineflix.cenaflixpodcast.model.Usuario;
import jakarta.persistence.EntityManager;

import java.awt.*;

public class CadastroScreen extends JFrame {
    private JTextField produtorField;
    private JTextField nomeEpisodioField;
    private JTextField numeroEpisodioField;
    private JTextField duracaoField;
    private JTextField urlRepositorioField;

    public CadastroScreen(Usuario user, EntityManager manager) {
        setTitle("CENAFLIX - Cadastrar Podcast");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 5, 5);
        c.fill = GridBagConstraints.HORIZONTAL;

        JLabel title = new JLabel("CENAFLIX", JLabel.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 2;
        panel.add(title, c);

        JLabel subtitle = new JLabel("CADASTRAR PODCAST", JLabel.CENTER);
        subtitle.setFont(new Font("Arial", Font.BOLD, 14));
        c.gridy = 1;
        panel.add(subtitle, c);

        c.gridwidth = 1;

        produtorField = addLabelAndTextField("Produtor:", panel, c, 2);
        nomeEpisodioField = addLabelAndTextField("Nome do Episódio:", panel, c, 3);
        numeroEpisodioField = addLabelAndTextField("N° do Episódio:", panel, c, 4);
        duracaoField = addLabelAndTextField("Duração:", panel, c, 5);
        urlRepositorioField = addLabelAndTextField("URL do repositório:", panel, c, 6);

        JButton cadastrarButton = new JButton("Cadastrar");
        c.gridx = 0;
        c.gridy = 7;
        panel.add(cadastrarButton, c);

        JButton verListagemButton = new JButton("Ver Listagem");
        c.gridx = 1;
        panel.add(verListagemButton, c);

        add(panel);
        setVisible(true);

        verListagemButton.addActionListener(e -> {
            dispose();
            new ListagemScreen(user, manager);
        });

        cadastrarButton.addActionListener(e -> {
            String produtor = produtorField.getText();
            String nomeEpisodio = nomeEpisodioField.getText();
            String numeroEpisodio = numeroEpisodioField.getText();
            String duracao = duracaoField.getText();
            String urlRepositorio = urlRepositorioField.getText();

            System.out.println("Produtor: " + produtor);
            System.out.println("Nome do Episódio: " + nomeEpisodio);
            System.out.println("N° do Episódio: " + numeroEpisodio);
            System.out.println("Duração: " + duracao);
            System.out.println("URL do Repositório: " + urlRepositorio);

            Podcast podcast = new Podcast();
            podcast.setUsuario(user);
            podcast.setProdutor(produtor);
            podcast.setNomeEpisodio(nomeEpisodio);
            podcast.setNumeroEpisodio(Integer.parseInt(numeroEpisodio));
            podcast.setDuracaoEpisodio(Integer.parseInt(duracao));
            podcast.setUrlRepositorio(urlRepositorio);

            manager.getTransaction().begin();
            manager.persist(podcast);
            manager.getTransaction().commit();

            JOptionPane.showMessageDialog(this, "Podcast cadastrado com sucesso!");
            dispose();
            new ListagemScreen(user, manager);
        });
    }

    private JTextField addLabelAndTextField(String labelText, JPanel panel, GridBagConstraints c, int yPos) {
        JLabel label = new JLabel(labelText);
        c.gridx = 0;
        c.gridy = yPos;
        panel.add(label, c);

        JTextField textField = new JTextField(15);
        c.gridx = 1;
        panel.add(textField, c);

        return textField;
    }
}
