CREATE DATABASE cenaflix;
USE cenaflix;
CREATE TABLE usuario(
    id INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    senha VARCHAR(255) NOT NULL,
    grant_sys ENUM('ADMIN', 'USER','OPER') NOT NULL
);
CREATE TABLE podcast(
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario_id INT NOT NULL,
    produtor VARCHAR(255) NOT NULL,
    nome_episodio VARCHAR(255) NOT NULL,
    numero_episodio INT NOT NULL,
    duracao_episodio INT NOT NULL,
    url_repositorio VARCHAR(255) NOT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuario(id)
);
INSERT INTO usuario(nome,email, senha, grant_sys) VALUES('Emerson','emerson@email.com','123456','ADMIN');
INSERT INTO usuario(nome,email, senha, grant_sys) VALUES('Joao','joao@email.com','123456','USER');
INSERT INTO usuario(nome,email, senha, grant_sys) VALUES('Lucas','lucas@email.com','123456','OPER');
