/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cenaflix;
import cenaflix.Screens.SignUpScreen;

/**
 * CenaFlix - Main class of the application
 * @author Emerson S.
 * @version 1.0
 */
public class CenaFlix {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new SignUpScreen();
    }

}
