package supermercado.Servicos;

import supermercado.Produto;

public interface IRepositorio {
   public boolean salvarProduto(Produto produto);
}
