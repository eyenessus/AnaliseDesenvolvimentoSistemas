package supermercado.Servicos;

public interface IServicos {
        public void enviarMensagem();
}
