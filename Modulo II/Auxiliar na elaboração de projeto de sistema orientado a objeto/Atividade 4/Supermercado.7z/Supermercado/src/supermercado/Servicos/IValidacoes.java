package supermercado.Servicos;

import supermercado.Produto;

public interface IValidacoes {
   boolean produtoValido(Produto produto);
}
