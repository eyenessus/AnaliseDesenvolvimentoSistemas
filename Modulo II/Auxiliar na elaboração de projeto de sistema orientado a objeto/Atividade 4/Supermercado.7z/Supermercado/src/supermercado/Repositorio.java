package supermercado;

import supermercado.Servicos.IRepositorio;
import supermercado.Servicos.IValidacoes;

public class Repositorio implements IRepositorio {
    IValidacoes validacoes;

    Repositorio(IValidacoes validacoes) {
        this.validacoes = validacoes;
    }

    public boolean salvarProduto(Produto produto) {
       if(validacoes.produtoValido(produto)){
           System.out.println("Produto salvo com sucesso!");
           return true;
       } else {
           System.out.println("Produto inválido!");
           return false;
       }
    }
}
