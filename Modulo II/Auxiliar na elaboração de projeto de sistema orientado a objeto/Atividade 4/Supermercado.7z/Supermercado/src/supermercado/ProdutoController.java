/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package supermercado;

import supermercado.Servicos.IRepositorio;
import supermercado.Servicos.IServicos;
import supermercado.Servicos.IValidacoes;

/**
 *
 * @author venec
 */
public class ProdutoController {
    IValidacoes validacoes;
    IRepositorio repositorioProdutos;
    IServicos servicos;

    ProdutoController(IValidacoes validacoes, IRepositorio repositorioProdutos, IServicos servicos) {
        this.validacoes = validacoes;
        this.repositorioProdutos = repositorioProdutos;
        this.servicos = servicos;
    }

    public boolean salvarProduto(Produto produto) {
        if (repositorioProdutos.salvarProduto(produto)) {
            servicos.enviarMensagem();
            return true;
        }
        return false;
    }

}
