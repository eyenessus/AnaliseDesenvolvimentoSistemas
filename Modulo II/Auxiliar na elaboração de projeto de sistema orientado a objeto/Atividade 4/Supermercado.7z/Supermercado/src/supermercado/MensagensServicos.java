package supermercado;

import supermercado.Servicos.IServicos;

public class MensagensServicos implements IServicos {

    public void enviarMensagem() {
        // enviar mensagem
    }
}
