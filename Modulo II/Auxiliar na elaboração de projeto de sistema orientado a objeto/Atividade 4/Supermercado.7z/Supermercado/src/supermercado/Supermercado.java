/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package supermercado;

import supermercado.Servicos.IRepositorio;
import supermercado.Servicos.IServicos;
import supermercado.Servicos.IValidacoes;

/**
 *
 * @author venec
 */
public class Supermercado {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        IValidacoes validacoes = new Validacoes();
        IRepositorio repositorioProdutos = new Repositorio(validacoes);
        IServicos servicos = new MensagensServicos();
        Produto produto = new Produto();
        
        ProdutoController controllerProduto = new ProdutoController(validacoes, repositorioProdutos, servicos);

        produto.setId(1);
        produto.setNome("Refrigerante");
        produto.setPreco(10.90);

        controllerProduto.salvarProduto(produto);
        

    }

}
