package supermercado;

import supermercado.Servicos.IValidacoes;

public class Validacoes implements IValidacoes{

    public boolean produtoValido(Produto produto){
        
        if (produto.getNome().equals("")){
            return false;
        } else {   
            return true;
        }
        
    }
}
