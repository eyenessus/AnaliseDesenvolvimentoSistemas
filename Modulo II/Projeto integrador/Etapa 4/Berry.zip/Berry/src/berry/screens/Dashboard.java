package berry.screens;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import berry.model.Item;

public class Dashboard extends JFrame {
    public Dashboard() {
        this.setTitle("Dashboard");
        this.setSize(800, 600);
        this.build();
    }

    public void build() {
        JPanel painelPrincipal = new JPanel(new BorderLayout(10, 10));
        painelPrincipal.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel painelSuperior = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        c.insets = new Insets(10, 10, 10, 10);

        JLabel titulo = new JLabel("Pedidos");
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        c.fill = GridBagConstraints.WEST;
        c.gridx = 0;
        c.gridy = 0;

        painelSuperior.add(titulo, c);

        JButton botaoSair = new JButton("Sair");
        c.fill = GridBagConstraints.EAST;
        c.gridx = 5;
        c.gridy = 0;
        painelSuperior.add(botaoSair, c);

        JTextField campoPesquisa = new JTextField(20);
        c.gridx = 2;
        c.gridy = 0;
        painelSuperior.add(campoPesquisa, c);

        painelPrincipal.add(painelSuperior, BorderLayout.NORTH);

        String[] columns = { "Pedido", "Nome", "Status", "Descrição", "Valor" };

        String[][] data = {
                { "001", "João Silva", "Em andamento", "Pizza Grande", "R$ 45,00" },
                { "002", "Maria Santos", "Entregue", "Hamburguer Duplo", "R$ 25,00" },
                { "003", "Pedro Alves", "Preparando", "Salada Caesar", "R$ 30,00" },
                { "004", "Ana Costa", "Em andamento", "Refrigerante 2L", "R$ 12,00" },
                { "005", "Carlos Lima", "Entregue", "Sobremesa", "R$ 15,00" }
        };

        // Usando DefaultTableModel corretamente
         DefaultTableModel model = new DefaultTableModel(data, columns);
        JTable table = new JTable(model);

        JScrollPane scrollPane = new JScrollPane(table);
        painelPrincipal.add(scrollPane, BorderLayout.CENTER);

        JPanel painelInferior = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));

        JButton botaoAdicionar = new JButton("Adicionar");
        botaoAdicionar.setBackground(Color.GREEN);
        painelInferior.add(botaoAdicionar);

        JButton botaoEditar = new JButton("Editar");
        botaoEditar.setBackground(Color.YELLOW);
        painelInferior.add(botaoEditar);

        JButton botaoExcluir = new JButton("Excluir");
        botaoExcluir.setBackground(Color.RED);
        painelInferior.add(botaoExcluir);

        painelInferior.add(botaoExcluir);
        painelInferior.add(botaoEditar);
        painelInferior.add(botaoAdicionar);

        painelPrincipal.add(painelInferior, BorderLayout.SOUTH);

        add(painelPrincipal);
        setVisible(true);

        botaoSair.addActionListener(e -> {
            System.exit(0);
        });

        botaoAdicionar.addActionListener(e -> {
            new CadastroItem();
        });

        botaoEditar.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Selecione um item para editar");
                return;
            }

            String id = (String) table.getValueAt(row, 0);
            String nome = (String) table.getValueAt(row, 1);
            String status = (String) table.getValueAt(row, 2);
            String descricao = (String) table.getValueAt(row, 3);
            String valor = (String) table.getValueAt(row, 4);

            Item item = new Item(id, nome, descricao, valor, status);
            new CadastroItem(item);
        });

        botaoExcluir.addActionListener(event -> {
            int row = table.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Selecione um item para excluir");
                return;
            }
            model.removeRow(row);
            JOptionPane.showMessageDialog(this, "Item excluído com sucesso");
        });

    }
}
