package berry.screens;

import java.awt.*;
import javax.swing.*;

import berry.model.Item;

public class CadastroItem extends JFrame {
    private Boolean editing = false;
    private Item item;

    public CadastroItem() {
        this.setTitle("Cadastro de Item");
        this.setSize(800, 400);
        this.setLocationRelativeTo(null);
        this.setLayout(new BorderLayout());
        this.build();
    }

    public CadastroItem(Item item) {
        this.editing = true;
        this.item = item;
        this.setTitle("Edição de Item");
        this.setSize(800, 400);
        this.setLocationRelativeTo(null);
        this.setLayout(new BorderLayout()); 
        this.build();
    }

    public void build() {
        JPanel painelPrincipal = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(10, 10, 10, 10); // Espaçamento
        c.fill = GridBagConstraints.HORIZONTAL;

        JLabel nomeLabel = new JLabel("NOME ITEM:");
        c.gridx = 0;
        c.gridy = 0;
        painelPrincipal.add(nomeLabel, c);

        JTextField nomeField = new JTextField(20);
        c.gridx = 1;
        painelPrincipal.add(nomeField, c);

        JLabel valorLabel = new JLabel("VALOR:");
        c.gridx = 2;
        painelPrincipal.add(valorLabel, c);

        JTextField valorField = new JTextField(10);
        c.gridx = 3;
        painelPrincipal.add(valorField, c);

        JLabel descricaoLabel = new JLabel("DESCRIÇÃO:");
        c.gridx = 0;
        c.gridy = 1;
        c.gridwidth = 4;
        painelPrincipal.add(descricaoLabel, c);

        JTextArea descricaoField = new JTextArea(5, 40);
        JScrollPane scrollPane = new JScrollPane(descricaoField);
        c.gridx = 0;
        c.gridy = 2;
        c.gridwidth = 4;
        c.fill = GridBagConstraints.BOTH; // Permite expansão do campo
        painelPrincipal.add(scrollPane, c);

        JPanel painelBotao = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton cadastrarBtn = new JButton("Cadastrar");

        if (this.editing) {
            System.out.println("Editing");
            this.setTitle("Editar Item");
            cadastrarBtn.setText("Editar");
            nomeField.setText(this.item.getNome());
            valorField.setText(this.item.getValor());
            descricaoField.setText(this.item.getDescricao());
        }

        cadastrarBtn.setBackground(new Color(34, 177, 76));
        cadastrarBtn.setForeground(Color.WHITE);
        painelBotao.add(cadastrarBtn);

        this.add(painelPrincipal, BorderLayout.CENTER);
        this.add(painelBotao, BorderLayout.SOUTH);

        this.setVisible(true);

        cadastrarBtn.addActionListener(e -> {
            String nome = nomeField.getText();
            String valor = valorField.getText();
            String descricao = descricaoField.getText();

            if (nome.isEmpty() || valor.isEmpty() || descricao.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Preencha todos os campos", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (this.editing) {
                JOptionPane.showMessageDialog(this, "Item atualizado com sucesso", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                dispose();  
            } else {
                JOptionPane.showMessageDialog(this, "Item cadastrado com sucesso", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                dispose();
            }
        });
    }
}
