package berry.screens;

import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import berry.services.LoginService;

public class LoginScreen extends JFrame {
    private LoginService serviceLogin;

    public LoginScreen() {
        this.serviceLogin = new LoginService();
        this.setTitle("Login");
        this.setSize(800, 600);
        this.setLayout(new GridBagLayout());
        this.build();
    }

    public void build() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(10, 10, 10, 10);
        c.fill = GridBagConstraints.HORIZONTAL;

        JLabel welcome = new JLabel("BERRY");
        welcome.setFont(new Font("Arial", Font.BOLD, 50));

        c.fill = GridBagConstraints.CENTER;
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 2;
        panel.add(welcome, c);

        JLabel username = new JLabel("Usuário");
        c.gridx = 0;
        c.gridy = 1;
        c.gridwidth = 1;
        panel.add(username, c);

        JTextField usernameField = new JTextField(25);
        c.gridx = 1;
        c.gridy = 1;
        c.gridwidth = 1;
        panel.add(usernameField, c);

        JLabel password = new JLabel("Senha");
        c.gridx = 0;
        c.gridy = 2;
        c.gridwidth = 1;
        panel.add(password, c);

        JTextField passwordField = new JTextField(25);
        c.gridx = 1;
        c.gridy = 2;
        c.gridwidth = 1;
        panel.add(passwordField, c);

        JButton login = new JButton("Entrar");
        c.gridx = 0;
        c.gridy = 3;
        c.gridwidth = 2;
        c.fill = GridBagConstraints.CENTER;

        panel.add(login, c);

        add(panel);
        setVisible(true);

        login.addActionListener(e -> {
            String user = usernameField.getText();
            String pass = passwordField.getText();
            serviceLogin.login(user, pass);
            dispose();
        });
    }
}
