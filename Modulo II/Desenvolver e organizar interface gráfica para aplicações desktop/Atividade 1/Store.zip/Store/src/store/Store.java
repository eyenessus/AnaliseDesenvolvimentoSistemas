package store;

import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import store.buttons.ButtonAction;

public class Store {
    public static void main(String[] args) {
        Screen screen = new Screen(800, 600);
        JPanel panel = new JPanel();
        JLabel label = new JLabel("Valor da venda");
        JTextField field = new JTextField(10);
        JButton button = new JButton("Calcular");

        screen.setTitle("Store Company");
        screen.setLayout(new FlowLayout());

        panel.add(label);
        panel.add(field);
        panel.add(button);
        screen.add(panel);

        button.addActionListener(new ButtonAction(field));
        screen.setVisible(true); 
    }
}
