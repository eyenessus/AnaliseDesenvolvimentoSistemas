package store.buttons;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class ButtonAction implements ActionListener {
    private JTextField amountString;

    public ButtonAction(JTextField amount) {
        this.amountString = amount;
    }

    public void actionPerformed(ActionEvent e) {
        Double amount = Double.parseDouble(this.amountString.getText());
        Double porcentual = 0.0;

        if (amount == 0) {
            JOptionPane.showMessageDialog(null, "Valor da venda não pode ser zero");
            return;
        }
        if (amount >= 500) {
            String amountPerc = JOptionPane.showInputDialog(null, "informar um percentual de desconto");
            porcentual = Double.parseDouble(amountPerc) / 100;

        } else if (amount >= 200) {
            String amountPerc = JOptionPane.showInputDialog(null, "informar um percentual de desconto");
            porcentual = Double.parseDouble(amountPerc) / 100;
            
        } else {
            JOptionPane.showMessageDialog(null, amount);
            return;
        }
        JOptionPane.showMessageDialog(null, "Valor do desconto: " + (amount * porcentual));
    }

}
