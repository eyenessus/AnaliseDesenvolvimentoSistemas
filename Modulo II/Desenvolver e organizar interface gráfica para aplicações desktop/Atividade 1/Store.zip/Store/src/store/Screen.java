package store;

import javax.swing.JFrame;

public class Screen extends JFrame {
    public Screen(Integer sizeX, Integer sizeY) {
        this.setSize(sizeX, sizeY);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
    
}
