/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package nutri;


import javax.swing.JButton;
import javax.swing.JPanel;

import nutri.screens.Gasto;
import nutri.screens.Imc;
import nutri.screens.Recomendacoes;
import nutri.screens.Screen;

/**
 *
 * @author emers
 */
public class Nutri {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Screen screen = new Screen();
        JPanel panel = new JPanel();
        JButton buttonImc = new JButton("IMC");
        JButton buttonGastoCalorico = new JButton("Gasto Calórico");
        JButton buttonRecomendacoes = new JButton("Recomendações");

        panel.add(buttonImc);
        panel.add(buttonGastoCalorico);
        panel.add(buttonRecomendacoes);
        screen.setTitle("NutriSoft");
        screen.add(panel);
       
        buttonImc.addActionListener(event -> {
            if(event.getSource() == buttonImc){
                Imc imc = new Imc();
                imc.build();
            }
        });

        buttonGastoCalorico.addActionListener(event -> {
            if(event.getSource() == buttonGastoCalorico){
                Gasto gasto = new Gasto();
                gasto.build();
            }
        });

        buttonRecomendacoes.addActionListener(event -> {
            if(event.getSource() == buttonRecomendacoes){
                Recomendacoes recomendacoes = new Recomendacoes();
                recomendacoes.build();
            }
        });

        screen.setVisible(true);
    }
    
}
