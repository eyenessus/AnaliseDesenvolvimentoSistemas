package nutri.screens;

import java.awt.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Imc extends JFrame {
    public Imc() {
        this.setSize(400, 300);
        this.setVisible(true);
        this.setTitle("IMC");
    }

    public void build() {
        JPanel main = new JPanel(new GridLayout(2, 1));
        JPanel panel = new JPanel();
        JPanel panel2 = new JPanel();

        JLabel label1 = new JLabel("Altura (m): ");
        JLabel label2 = new JLabel("Peso (kg): ");
        JTextField field1 = new JTextField(10);
        JTextField field2 = new JTextField(10);

        JButton button = new JButton("Calcular");

        JLabel resultLabel = new JLabel("Resultado: ");
        JLabel interLabel = new JLabel("Interpretação: ");

        panel.add(label1);
        panel.add(field1);
        panel.add(label2);
        panel.add(field2);
        panel.add(button);

        panel2.add(resultLabel);
        panel2.add(interLabel);

        main.add(panel);
        main.add(panel2);
        main.setVisible(true);

        add(main);

        button.addActionListener(event -> {
            try {
                double altura = Double.parseDouble(field1.getText());
                double peso = Double.parseDouble(field2.getText());

                double imc = peso / (altura * altura);
                String result = String.format("IMC: %.2f", imc);
                String inter = "";

                if (imc < 18.5) {
                    inter = "Magreza";
                } else if (imc >= 18.5 && imc < 24.9) {
                    inter = "Normal";
                } else if (imc >= 25 && imc < 29.9) {
                    inter = "Sobrepeso";
                } else if (imc >= 30 && imc < 39.9) {
                    inter = "Obesidade";
                } else {
                    inter = "Obesidade grau grave";
                }

                resultLabel.setText(result);
                interLabel.setText(inter);
            } catch (Exception e) {
                resultLabel.setText("Erro, verifique os valores inseridos");
                interLabel.setText("Erro, verifique os valores inseridos");
            }
        });

        setVisible(true);
    }
}
