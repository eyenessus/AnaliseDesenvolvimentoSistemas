package nutri.screens;

import javax.swing.*;
import java.awt.*;

public class Gasto extends JFrame {
    public Gasto() {
        this.setSize(800, 600);
        this.setTitle("Gasto Calórico");
    }

    public void build() {
        JPanel main = new JPanel(new GridLayout(2, 2));
        JPanel panel = new JPanel();
        JPanel panel2 = new JPanel();
        JLabel title = new JLabel("Cálculo de gasto calórico");

        JTextField pesoField = new JTextField(15);
        JLabel pesoLabel = new JLabel("Peso (kg):");

        JTextField alturaField = new JTextField(15);
        JLabel alturaLabel = new JLabel("Altura (cm):");

        JTextField idadeField = new JTextField(15);
        JLabel idadeLabel = new JLabel("Idade:");

        JRadioButton mascRadio = new JRadioButton("Masculino");
        JRadioButton feminRadio = new JRadioButton("Feminino");

        ButtonGroup genderGroup = new ButtonGroup();
        genderGroup.add(mascRadio);
        genderGroup.add(feminRadio);

        JLabel atividadeLabel = new JLabel("Nível de atividade:");
        JList<String> listAtividade = new JList<>();
        listAtividade.setListData(new String[]{"Sedentário", "Leve", "Modera", "Ativo","Extramente ativo"});
        listAtividade.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JButton button = new JButton("Calcular");

        JLabel gastoBasa = new JLabel("Gasto basal: ");
        JLabel gastoTotal = new JLabel("Gasto total: ");

        panel.add(title);
        panel.add(pesoLabel);
        panel.add(pesoField);
        panel.add(mascRadio);
        panel.add(feminRadio);
        panel.add(alturaLabel);
        panel.add(alturaField);
        panel.add(idadeLabel);
        panel.add(idadeField);
        panel.add(atividadeLabel);
        panel.add(listAtividade);
        panel.add(button);

        panel2.add(gastoBasa);
        panel2.add(gastoTotal);

        main.add(panel);
        main.add(panel2);

        button.addActionListener(e->{
            if(e.getSource() == button){
                try {
                    int idade = Integer.parseInt(idadeField.getText());
                    Double peso = Double.parseDouble(pesoField.getText());
                    Double altura = Double.parseDouble(alturaField.getText());
                    Double gastoBasal = 0.0;
                    Double atividade = 0.0;

                    String gender = genderGroup.getSelection().getActionCommand();

                    if ("Masculino".equals(gender)) {
                        gastoBasal = 66 + (13.7 * peso) + (5 * altura) - (6.8 * idade);
                    } else {
                        gastoBasal = 655 + (9.6 * peso) + (1.9 * altura) - (4.7 * idade);
                    }
                    
                    String selectedAtividade = listAtividade.getSelectedValue();
                    
                    if (selectedAtividade != null) {
                        switch (selectedAtividade) {
                            case "Sedentário" -> atividade = gastoBasal * 1.2;
                            case "Leve" -> atividade = gastoBasal * 1.375;
                            case "Modera" -> atividade = gastoBasal * 1.55;
                            case "Ativo" -> atividade = gastoBasal * 1.725;
                            case "Extramente ativo" -> atividade = gastoBasal * 1.9;
                        }
                    }

                    gastoBasa.setText("Gasto basal: " + gastoBasal);
                    gastoTotal.setText("Gasto total: " + atividade);
                } catch (Exception event) {
                    gastoBasa.setText("Erro, verifique os valores inseridos");
                    gastoTotal.setText("Erro, verifique os valores inseridos");
                }
            }
        });
        
        add(main);
        setVisible(true);
    }

   
}
