package nutri.screens;

import javax.swing.JFrame;

public class Screen extends JFrame {
    public Screen() {
        this.setSize(800, 600);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
}
