package nutri.screens;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.*;
public class Recomendacoes extends JFrame {
    public Recomendacoes() {
        this.setSize(800, 600);
        this.setTitle("Recomendações Nutricionais");
    }

    public void build() {
        JPanel main = new JPanel(new GridLayout(2, 2));
        JPanel panel = new JPanel();
        JPanel panel2 = new JPanel();

        JLabel title = new JLabel("Recomendações Nutricionais");
        JLabel calorDiaria = new JLabel("Calorias diárias (kcal):");

        JTextField caloriasField = new JTextField(15);
        JButton button = new JButton("Calcular");

        JLabel carboidratos = new JLabel("Carboidratos 50%: ");
        JLabel proteinas = new JLabel("Proteínas 25%: ");
        JLabel gorduras = new JLabel("Gorduras 25%: ");
        
        panel.add(title);
        panel.add(calorDiaria);
        panel.add(caloriasField);
        panel.add(button);

        panel2.add(carboidratos);
        panel2.add(proteinas);
        panel2.add(gorduras);

        main.add(panel);
        main.add(panel2);
        add(main);

        button.addActionListener(event -> {
            try {
                double calorias = Double.parseDouble(caloriasField.getText());
                double carb = calorias * 0.5;
                double prot = calorias * 0.25;
                double gord = calorias * 0.25;

                carboidratos.setText("Carboidratos 50% (g): " +String.format("%.2f", carb));
                proteinas.setText("Proteínas 25% (g): "+String.format("%.2f", prot));
                gorduras.setText("Gorduras 25% (g): " +String.format("%.2f", gord));
            } catch (NumberFormatException e) {
                System.out.println("Erro: " + e.getMessage());
            }
        });

        setVisible(true);
    }
}
