package sindicatonutrica.model;

public class Paciente {
    public String nome;
    public String cpf;
    public Boolean jaEPaciente;
    public String telefone;
    public String data;

    public Paciente(String nome, String cpf, Boolean jaEPaciente, String telefone,String data) {
        this.nome = nome;
        this.cpf = cpf;
        this.jaEPaciente = jaEPaciente;
        this.telefone = telefone;
        this.data = data;
    }
}
