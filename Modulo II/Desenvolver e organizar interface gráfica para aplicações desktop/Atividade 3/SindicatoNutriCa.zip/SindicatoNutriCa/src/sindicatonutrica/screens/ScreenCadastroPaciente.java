package sindicatonutrica.screens;

import java.awt.GridLayout;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import sindicatonutrica.model.Paciente;

public class ScreenCadastroPaciente extends JFrame {
   private ArrayList<Paciente> pacientes;
    private DefaultTableModel tableModel;

    public ScreenCadastroPaciente(ArrayList<Paciente> pacientes, DefaultTableModel tableModel) {
        this.pacientes = pacientes;
        this.tableModel = tableModel;
        setTitle("Cadastro de paciente");
        setSize(800, 600);
        setLocationRelativeTo(null);
    }

    public void build() {
        JLabel title = new JLabel("Cadastro de paciente");
        JLabel nome = new JLabel("Nome do paciente:");
        JLabel telefone = new JLabel("Telefone:");
        JLabel cpf = new JLabel("CPF:");
        JLabel dataConsulta = new JLabel("Data da consulta:");
        JLabel jaEPaciente = new JLabel("Já é paciente?");

        JButton cadastrar = new JButton("Cadastrar");

        JTextField nomeField = new JTextField(20);
        JTextField telefoneField = new JTextField(20);
        JTextField cpfField = new JTextField(20);
        JTextField dataConsultaField = new JTextField(20);
        JTextField jaEPacienteField = new JTextField(20);

        JCheckBox jaEPacienteCheckBox = new JCheckBox();

        JPanel mainPanel = new JPanel(new GridLayout(0, 1));

        mainPanel.add(title);
        mainPanel.add(nome);
        mainPanel.add(nomeField);
        mainPanel.add(telefone);
        mainPanel.add(telefoneField);
        mainPanel.add(cpf);
        mainPanel.add(cpfField);
        mainPanel.add(dataConsulta);
        mainPanel.add(dataConsultaField);
        mainPanel.add(jaEPaciente);
        mainPanel.add(jaEPacienteCheckBox);
        mainPanel.add(cadastrar);
        mainPanel.add(jaEPacienteField);

        cadastrar.addActionListener(e -> {
            if (e.getSource() == cadastrar) {
                try {
                    String nomePaciente = nomeField.getText();
                    String telefonePaciente = telefoneField.getText();
                    String cpfPaciente = cpfField.getText();
                    String dataConsultaPaciente = dataConsultaField.getText();
                    Boolean jaEPacientePaciente = jaEPacienteCheckBox.isSelected();
                    Paciente paciente = new Paciente(nomePaciente,cpfPaciente,jaEPacientePaciente,telefonePaciente,dataConsultaPaciente);
                    pacientes.add(paciente);

                    boolean cpfValido = cpfPaciente.matches("[0-9]{3}[.][0-9]{3}[.][0-9]{3}[-][0-9]{2}");
                    boolean dataValida = dataConsultaPaciente.matches("[0-9]{2}[/][0-9]{2}[/][0-9]{4}");

                    if(nomePaciente.isEmpty() || telefonePaciente.isEmpty() || cpfPaciente.isEmpty() || dataConsultaPaciente.isEmpty()) {
                        JOptionPane.showMessageDialog(null,"Todos os campos são obrigatórios");
                        return;
                    }

                    if(telefonePaciente.length() < 8) {
                        JOptionPane.showMessageDialog(null, "Telefone inválido");
                        return;
                    }

                    if(!cpfValido) {
                        JOptionPane.showMessageDialog(null, "CPF inválido ou em formato inválido");
                        return;
                    }

                    if(!dataValida) {
                        JOptionPane.showMessageDialog(null, "Data inválida ou em formato inválido");
                        return;
                    }

                    String[] row = { nomePaciente, cpfPaciente, telefonePaciente, dataConsultaPaciente, jaEPacientePaciente.toString() == "true" ? "Sim" : "Não", "Não","" };
                    tableModel.addRow(row);
                    dispose();

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        add(mainPanel);
        setVisible(true);
    }

    
}
