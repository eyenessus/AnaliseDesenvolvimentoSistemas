package sindicatonutrica.screens;

import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import sindicatonutrica.model.Paciente;

public class ScreenExcluirPaciente extends JFrame {
    private ArrayList<Paciente> pacientes;
    private JTable table;
    private DefaultTableModel tableModel;

    public ScreenExcluirPaciente(ArrayList<Paciente> pacientes, JTable table, DefaultTableModel tableModel) {
        this.pacientes = pacientes;
        this.table = table;
        this.tableModel = tableModel;

        setTitle("Excluir paciente");
        setSize(400, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }

    public void build() {
        JLabel title = new JLabel("Excluir paciente");
        JButton excluir = new JButton("Excluir");
        JButton cancelar = new JButton("Cancelar");

        JPanel mainPanel = new JPanel();
        mainPanel.add(title);
        mainPanel.add(excluir);
        mainPanel.add(cancelar);

        add(mainPanel);

        excluir.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                pacientes.remove(selectedRow);
                tableModel.removeRow(selectedRow);
                dispose();
            } else {
                System.out.println("Nenhuma linha selecionada para exclusão!");
            }
        });

        cancelar.addActionListener(e -> dispose());

        setVisible(true);
    }
}
