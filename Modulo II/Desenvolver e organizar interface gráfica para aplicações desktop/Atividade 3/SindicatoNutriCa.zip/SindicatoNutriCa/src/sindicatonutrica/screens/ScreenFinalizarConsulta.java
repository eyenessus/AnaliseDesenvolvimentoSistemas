package sindicatonutrica.screens;

import java.awt.FlowLayout;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;

import sindicatonutrica.model.Paciente;

public class ScreenFinalizarConsulta extends JFrame {
    private ArrayList<Paciente> pacientes;
    private JTable table;
    private DefaultTableModel tableModel;

    public ScreenFinalizarConsulta(ArrayList<Paciente> pacientes, JTable table, DefaultTableModel tableModel) {
        setTitle("Finalizar consulta");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.pacientes = pacientes;
        this.table = table;
        this.tableModel = tableModel;
    }

    public void build() {
        setTitle("Detalhes da consulta");
        JPanel mainPanel = new JPanel(new FlowLayout());
        JLabel consultaRealizadaLabel = new JLabel("Consulta realizada?");
        JLabel receitaEObservacoesLabel = new JLabel("Receita e observações:");
        JButton finalizarConsulta = new JButton("Finalizar consulta");
        JCheckBox consultaRealizadaCheckBox = new JCheckBox();
        JTextArea receitaEObservacoesTextArea = new JTextArea(10, 20);

            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                consultaRealizadaCheckBox.setSelected(tableModel.getValueAt(selectedRow, 5) == "Sim");
                if (consultaRealizadaCheckBox.isSelected()) {
                    consultaRealizadaCheckBox.setEnabled(false);
                    finalizarConsulta.setEnabled(false);
                }
        
                receitaEObservacoesTextArea.setText((String) tableModel.getValueAt(selectedRow, 6));
            } else {
                JOptionPane.showMessageDialog(null, "Nenhuma linha selecionada para finalização da consulta!");
                return;
            }
       

        finalizarConsulta.addActionListener(e -> {
            if(receitaEObservacoesTextArea.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Campo de receita e observações não pode estar vazio!");
                return;
            }
            
            if (selectedRow != -1) {
                tableModel.setValueAt(consultaRealizadaCheckBox.isSelected() ? "Sim" : "Não", selectedRow, 5);
                tableModel.setValueAt(receitaEObservacoesTextArea.getText(), selectedRow, 6);
                dispose();
            } else {
                JOptionPane.showMessageDialog(null, "Nenhuma linha selecionada para finalização da consulta!");
                return;
            }
        });
        
        mainPanel.add(consultaRealizadaLabel);
        mainPanel.add(consultaRealizadaCheckBox);
        mainPanel.add(receitaEObservacoesLabel);
        mainPanel.add(receitaEObservacoesTextArea);
        mainPanel.add(finalizarConsulta);



        add(mainPanel);
        setVisible(true);
    }
}
