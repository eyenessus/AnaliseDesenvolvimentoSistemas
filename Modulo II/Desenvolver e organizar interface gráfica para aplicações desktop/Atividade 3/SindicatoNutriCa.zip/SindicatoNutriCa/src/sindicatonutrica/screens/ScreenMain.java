package sindicatonutrica.screens;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import sindicatonutrica.model.Paciente;

import java.awt.BorderLayout;
import java.util.ArrayList;

public class ScreenMain extends JFrame {

    public ScreenMain() {
        setTitle("Sindicato NutriCa");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    public void build() {
        JLabel title = new JLabel("Boas vindas ao sistema de agendamento");

        ArrayList<Paciente> pacientes = new ArrayList<>();

        String[][] data = {};

        String[] columnNames = { "Paciente", "CPF", "Telefone", "Data", "Já é paciente?", "Consulta realizada?","Receitas e observações" };

        JTable table = new JTable(data, columnNames);
        JScrollPane scrollPane = new JScrollPane(table);

        DefaultTableModel tableModel = new DefaultTableModel(columnNames,0);

        JButton novoPaciente = new JButton("Cadastrar novo paciente");
        JButton excluirPaciente = new JButton("Excluir paciente");
        JButton finalizarConsulta = new JButton("Finalizar consulta");

        JPanel buttonsPanel = new JPanel();
        buttonsPanel.add(novoPaciente);
        buttonsPanel.add(excluirPaciente);
        buttonsPanel.add(finalizarConsulta);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(title, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        add(mainPanel);
        add(buttonsPanel, BorderLayout.SOUTH);

        loadTable(tableModel,table,pacientes);

        novoPaciente.addActionListener(e -> {
            if (e.getSource() == novoPaciente) {
                new ScreenCadastroPaciente(pacientes,tableModel).build();
            }
        });

        excluirPaciente.addActionListener(e -> {
            if (e.getSource() == excluirPaciente) {
                new ScreenExcluirPaciente(pacientes, table, tableModel).build();
            }
        });

        finalizarConsulta.addActionListener(e -> {
            if (e.getSource() == finalizarConsulta) {
                new ScreenFinalizarConsulta(pacientes,table,tableModel).build();
            }
        });

        setVisible(true);
    }

    public void loadTable(DefaultTableModel tableModel,JTable table, ArrayList<Paciente> pacientes) {
        for (int i = 0; i < pacientes.size(); i++) {
            Paciente paciente = pacientes.get(i);
            String[] row = { paciente.nome, paciente.cpf, paciente.telefone, paciente.data,
                    paciente.jaEPaciente.toString(), "Não" };
            tableModel.addRow(row);
        }
        table.setModel(tableModel);
    }
}
