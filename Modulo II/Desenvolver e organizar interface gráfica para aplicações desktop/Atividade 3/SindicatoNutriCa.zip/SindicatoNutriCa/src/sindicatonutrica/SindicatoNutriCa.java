/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sindicatonutrica;

import sindicatonutrica.screens.ScreenMain;

/**
 *
 * @author emers
 */
public class SindicatoNutriCa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ScreenMain screen  =new ScreenMain();
        screen.build();

    }
    
}
